public class Scanner {
 int counter = 0;
 int number ;
 public Scanner(int number ) {

   this.number = number;

 }
  // place the counter outside of the method to avoid getting fucked results.
 public void go(int no ){

   // Set the base case as 1 , so that if you reach the base case it wont go deeper

   if(no == 1 ) {
     // This is the last one ! 
     counter++;
     System.out.print( "We have finished in ..." + counter + "steps");

   }

   // if the number is even
   else if ((no % 2) == 0) {
     counter++;
     System.out.print(no + " ");
     go( no / 2 );

   }
   // if the number is odd
   else if ((no % 2) != 0) {
     counter++;
     System.out.print(no + " ");
     go( (no * 3) + 1 );
   }
   // if there is an error
   else {
     System.out.print("\n You have done something wrong... ");
   }
 }

 public static void main(String[] args) {
   Scanner terminate =  new Scanner(40);
   terminate.go(30);

 }

}
